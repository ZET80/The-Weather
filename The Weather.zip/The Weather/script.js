const result = document.getElementById("result")
const searchButton = document.getElementById("button")
const cityRef = document.getElementById("city")

// --------- API key from openweathermap.org ---------
const key = `bed642b2640b2ac30b9ff00dc0f646f5`

// --------- Function to fetch weather details from API ---------
const getWeather = () => {
  const cityValue = cityRef.value
  // If input field is empty
  if (cityValue.length === 0) {
    result.innerHTML = `<h5 class="message">Please enter a city name</h5>`
  }
  // --------- If input field is not empty ---------
  else {
    const link = `https://api.openweathermap.org/data/2.5/weather?q=${cityValue}&appid=${key}&units=metric`
    // --------- Clear the input field ---------
    cityRef.value = ""
    fetch(link)
      .then((resp) => resp.json())
      // --------- If city name is valid ---------
      .then((data) => {
        console.log(data)
        result.innerHTML = `
        <h2>${data.name}, ${data.sys.country}</h2>
          <p class="description">${data.weather[0].description}</p>
            <img src="https://openweathermap.org/img/wn/${data.weather[0].icon}@4x.png">
              <h3>${data.main.temp.toFixed(1)} &#176;</h3>
                <div class="information">
                    <div>
                      <p class="title">min</p>
                      <p class="temp">${data.main.temp_min.toFixed(1)}&#176;</p>
                    </div>
                    <div>
                      <p class="title">max</p>
                      <p class="temp">${data.main.temp_max.toFixed(1)}&#176;</p>
                    </div>
                  </div>
                <div class="information">
                    <div>
                      <p class="title">feels like</p>
                      <p class="temp">${data.main.feels_like.toFixed(1)}&#176</p>
                    </div>
                    <div>
                      <p class="title">wind</p>
                      <p class="temp">${data.wind.speed.toFixed(1)} km/h</p>
                    </div>
                </div>
                <div class="information">
                    <div>
                      <p class="title">humidity</p>
                      <p class="temp">${Math.round(data.main.humidity)}%</p>
                    </div>
                    <div>
                      <p class="title">pressure</p>
                      <p class="temp">${Math.round(data.main.pressure)} mbar</p>
                    </div>
                </div>
              `
      })
      // --------- If city name is not valid and other errors ---------
      .catch(() => {
        if (navigator.onLine) {
          result.innerHTML = `<h5 class="message">City not found</h5>`
        } else {
          result.innerHTML = `<h5 class="message">Please check internet connection</h5>`
        }
      })
  }
}

// --------- If button is presed, return information from API ---------
searchButton.addEventListener("click", getWeather)

// --------- If enter key is presed, return button from above ---------
cityRef.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    document.getElementById("button").click()
  }
})

// --------- If enter key is released, lose focus ---------
function enterDetector(button) {
  if (button.key === "Enter") {
    this.blur()
  }
}
cityRef.addEventListener("keyup", enterDetector)
